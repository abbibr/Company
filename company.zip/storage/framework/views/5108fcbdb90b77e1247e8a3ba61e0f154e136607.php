<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Phone List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        body{
            background: #eee;
        }
    </style>
</head>
<body>

    <div class="container">
        <h3 class="mt-2">My phone numbers</h3>
        <table class="table table-dark mt-3">
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Created date</th>
            </tr>
            <?php $__currentLoopData = $user->phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index + 1); ?></td>
                    <td><?php echo e($phone->name); ?></td>
                    <td><?php echo e($phone->phone); ?></td>
                    <td><?php echo e($phone->created_at->diffForHumans()); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    
</body>
</html><?php /**PATH D:\OpenServer\domains\company\resources\views/list.blade.php ENDPATH**/ ?>