

<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table table-dark mt-1">
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->index + 1); ?></td>
                    <td><a href="<?php echo e(route('phonelist', $user->id)); ?>"><?php echo e($user->name); ?></a></td>
                    <td><?php echo e($user->email); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h5>There are not any users!</h5>
            <?php endif; ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\company\resources\views/admin/phone.blade.php ENDPATH**/ ?>