

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4 class="text-center text-primary">
            Phones from <?php echo e($users->name); ?>

        </h4>
        <table class="table table-dark">
            <tr>
                <th>ID</th>
                <th>Company Name</th>
                <th>Phone</th>
            </tr>
            <?php $__currentLoopData = $users->phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($users->id); ?></td>
                    <td><?php echo e($users->name); ?></td>
                    <td><?php echo e($users->phone); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\company\resources\views/admin/list.blade.php ENDPATH**/ ?>