

<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table table-dark">
            <tr>
                <th>#</th>
                <th>Company Name</th>
                <th>Phone</th>
            </tr>
            <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $query): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index + 1); ?></td>
                    <td><?php echo e($query->name); ?></td>
                    <td><?php echo e($query->phone); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\company\resources\views/admin/search.blade.php ENDPATH**/ ?>